CREATE TABLE IF NOT EXISTS pet (
  id      SERIAL        PRIMARY KEY,
  name    VARCHAR(255),
  species VARCHAR(255)
);
