/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See LICENSE in the project root for
 * license information.
 */

package com.microsoft.azure.samples.spring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class PetRepository {

    private static final String SQL_FIND_BY_ID = "SELECT * FROM PET WHERE ID = :id";
    private static final String SQL_FIND_ALL = "SELECT TOP(20) * FROM accounts WHERE RM IS NULL";
    private static final String SQL_UPDATE = "UPDATE accounts SET rm =':RM1' WHERE bos_ac_no=:BOS_Ac_No1";
    //private static final String SQL_UPDATE = "UPDATE accounts SET RM ='Hussain T' WHERE Bos_Ac_No=120777";
    private static final String SQL_INSERT = "INSERT INTO PET (NAME, SPECIES) values(:name, :species)";
    private static final String SQL_DELETE_BY_ID = "DELETE FROM PET WHERE ID = :id";

    private static final BeanPropertyRowMapper<Pet> ROW_MAPPER = new BeanPropertyRowMapper<>(Pet.class);

    private static final Logger log = LoggerFactory.getLogger(PetRepository.class);
    
    @Autowired
    NamedParameterJdbcTemplate jdbcTemplate;

    public Pet findById(Integer id) {
        try {
            final SqlParameterSource paramSource = new MapSqlParameterSource("id", id);
            return jdbcTemplate.queryForObject(SQL_FIND_BY_ID, paramSource, ROW_MAPPER);
        }
        catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }

    public Iterable<Pet> findAll() {
    	log.info("Test log message");
    	System.out.println(jdbcTemplate.query(SQL_FIND_ALL, ROW_MAPPER).toString().replaceAll("\\[|\\]|[,][ ]","\t"));
        return jdbcTemplate.query(SQL_FIND_ALL, ROW_MAPPER);
    }
    
    public int save(Pet pet) {
        final SqlParameterSource paramSource = new MapSqlParameterSource()
                .addValue("RM", pet.getrm())
                .addValue("BOS_Ac_No", pet.getbosacno());

        return jdbcTemplate.update(SQL_INSERT, paramSource);
    }

    public void assignaccount(Pet pet) {
        final SqlParameterSource paramSource = new MapSqlParameterSource()
                .addValue("RM1", pet.getrm())
                .addValue("BOS_Ac_No1", pet.getbosacno());
       	log.info("RM1 = " + pet.getrm());
       	log.info("BOS_Ac_No1 = " + pet.getbosacno());
        jdbcTemplate.update(SQL_UPDATE, paramSource);
    }
    
    public void deleteById(Integer id) {
        final SqlParameterSource paramSource = new MapSqlParameterSource("id", id);
        jdbcTemplate.update(SQL_DELETE_BY_ID, paramSource);
    }
}
