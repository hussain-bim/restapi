/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See LICENSE in the project root for
 * license information.
 */

package com.microsoft.azure.samples.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




@Controller
@RequestMapping(path="/pets1")



public class PetController {
    @Autowired
    private PetRepository petRepository;

    @PostMapping
    public @ResponseBody String createPet(@RequestBody Pet pet) {
        petRepository.save(pet);
        return String.format("Added %s", pet);
    }

    @PutMapping
    public @ResponseBody String updatePet(@RequestBody Pet pet) {

    	final Logger log = LoggerFactory.getLogger(PetRepository.class);

    	log.info("Request Body " + pet);
       	log.info("RM1 = " + pet.getrm());
       	log.info("BOS_Ac_No1 = " + pet.getbosacno());

    	petRepository.assignaccount(pet);
       	return String.format("Updated %s", pet);
    }
    

    
    @GetMapping
    public @ResponseBody Iterable<Pet> getAllPets() {
        return petRepository.findAll();
    }

    @GetMapping("/{id}")
    public @ResponseBody Optional<Pet> getPet(@PathVariable Integer id) {
        return Optional.ofNullable(petRepository.findById(id));
    }

    @DeleteMapping("/{id}")
    public @ResponseBody String deletePet(@PathVariable Integer id) {
        petRepository.deleteById(id);
        return "Deleted " + id;
    }
}
